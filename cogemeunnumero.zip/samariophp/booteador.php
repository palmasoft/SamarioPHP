<?php
// Cargar la configuración
require_once __DIR__ . '/../base.php';
$configuracion = require_once RUTA_CONFIGURACION;
// Validar configuración crítica
$validador = require_once RUTA_CONFIG_VALIDACION;
$validador($configuracion);
//
$GLOBALS['config'] = $configuracion;

//cargar librerias de composer
require_once RUTA_LIBRERIAS;
// 
// 
// Configurar logs con Monolog
// Cargar configuración de logs
$configurarLogs = require_once RUTA_CONFIG_LOGS;
$loggers = $configurarLogs();
$loggerAplicacion = $loggers['aplicacion'];
$loggerServidor = $loggers['servidor'];
$loggerEjecucion = $loggers['ejecucion'];
$loggerEventos = $loggers['eventos'];
// 
// Registro de inicio del sistema
$loggerEventos->info('El sistema inició correctamente.');
//
// Manejo de errores
$gestorErrores = require_once RUTA_CONFIG_ERRORES;
$gestorErrores($loggerServidor, $configuracion);
// 
// Configuración de Medoo para la base de datos
$BaseDeDatos = require_once RUTA_CONFIG_BASEDEDATOS;
$GLOBALS['db'] = $BaseDeDatos($configuracion, $loggerAplicacion); // Hacer disponible la conexión en todo el proyecto
//
// Configuración de Slim
$slimConfig = require_once RUTA_CONFIG_SLIM;
$aplicacion = $slimConfig($configuracion, $plantillas, $loggerAplicacion);
//
// Registrar middleware de mantenimiento//
$mantenimiento = require_once RUTA_MANTENIMIENTO;
$aplicacion->add($mantenimiento);
// 
// Cargar rutas
$rutas = require_once RUTA_ENRUTADOR;
$rutas($aplicacion, $configuracion, $BaseDeDatos, $plantillas, $loggerEjecucion);
//