<?php
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Scripting/EmptyPHP.php to edit this template
 */
require_once DIR_BASE_DATOS . 'Conexion.php';
use SamarioPHP\BaseDeDatos\Conexion;
return function ($configuracion, $logger) {
  $Conexion = new Conexion($configuracion);
  return $Conexion;
};
