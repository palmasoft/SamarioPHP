<!-- verificar_correo.html.php -->
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Verificación de Correo</title>
    <link rel="stylesheet" href="/publico/css/estilos.css">
</head>
<body>
    <div class="container">
        <h2>Verificación de Correo</h2>
        <p>Su correo ha sido verificado exitosamente. Ahora puede iniciar sesión.</p>
        <p><a href="/login">Iniciar sesión</a></p>
    </div>
</body>
</html>
