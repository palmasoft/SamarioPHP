<?php
use App\Servicios\CorreosElectronicos;
namespace App\Controladores;
use App\Modelos\Usuario;
use SamarioPHP\Controlador;
use SamarioPHP\Respuesta;

class AutenticacionControlador extends Controlador {
  function enviarCorreoVerificacion($email, $token) {
    $mailer = new Mailer();
    $asunto = 'Verificación de Correo';
    $cuerpo = 'Haz clic en el siguiente enlace para verificar tu correo: <a href="https://tu-dominio.com/verificar?token=' . $token . '">Verificar Correo</a>';
    $mailer->enviarCorreo($email, $asunto, $cuerpo);
  }

  public function iniciarSesion() {
    // Verificar si el usuario ya está autenticado
    if ($this->sesion->estaAutenticado()) {
      return $this->redirigir('/dashboard');
    }

    // Procesar la petición POST para iniciar sesión
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
      $correo = $_POST['correo'];
      $contrasena = $_POST['contrasena'];

      // Buscar el usuario en la base de datos
      $usuario = Usuario::buscarPorCorreo($correo);

      // Verificar contraseña
      if ($usuario && password_verify($contrasena, $usuario->contrasena)) {
        // Iniciar sesión
        $this->sesion->iniciar($usuario->id);
        return $this->redirigir('/dashboard');
      } else {
        return $this->mostrarVista('login', ['error' => 'Credenciales inválidas']);
      }
    }

    return $this->mostrarVista('login');
  }

  public function registrarUsuario() {
    // Procesar la petición POST para registrar un nuevo usuario
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
      $nombre = $_POST['nombre'];
      $correo = $_POST['correo'];
      $contrasena = $_POST['contrasena'];

      // Validar datos del usuario (puedes agregar más validaciones)
      if (empty($nombre) || empty($correo) || empty($contrasena)) {
        return $this->mostrarVista('registro', ['error' => 'Todos los campos son requeridos']);
      }

      // Crear un nuevo usuario
      $usuario = new Usuario();
      $usuario->nombre = $nombre;
      $usuario->correo = $correo;
      $usuario->contrasena = password_hash($contrasena, PASSWORD_DEFAULT);
      $usuario->guardar();

      // Redirigir a la página de inicio de sesión
      return $this->redirigir('/login');
    }

    return $this->mostrarVista('registro');
  }

  public function cerrarSesion() {
    // Cerrar sesión
    $this->sesion->cerrar();
    return $this->redirigir('/login');
  }
}