<!-- login.html.php -->
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Iniciar sesión</title>
    <link rel="stylesheet" href="/publico/css/estilos.css">
</head>
<body>
    <div class="container">
        <h2>Iniciar sesión</h2>
        <form action="/login" method="POST">
            <label for="correo">Correo electrónico</label>
            <input type="email" id="correo" name="correo" required placeholder="Ingrese su correo electrónico">

            <label for="contrasena">Contraseña</label>
            <input type="password" id="contrasena" name="contrasena" required placeholder="Ingrese su contraseña">

            <button type="submit">Iniciar sesión</button>
        </form>
        <p><a href="/recuperar-clave">¿Olvidaste tu contraseña?</a></p>
        <p><a href="/registro">¿No tienes cuenta? Regístrate aquí</a></p>
    </div>
</body>
</html>
