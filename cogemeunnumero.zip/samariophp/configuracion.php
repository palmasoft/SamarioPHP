<?php

return [
    'base_de_datos' => [
        'tipo' => 'mysql',
        'servidor' => '162.240.97.33',
        'puerto' => 3306,
        'nombre_basedatos' => 'c0g3num3r0_l4r4v3lAPP',
        'nombre_usuario' => 'c0g3num3r0_l4r4v3l_USER',
        'clave_usuario' => 'CNCwJz!]aL!]',
        'conjunto_caracteres' => 'utf8',
    ],
    'aplicacion' => [
        'nombre' => 'Coge Un Numero - Elige tu suerte!!! ',
        'url_base' => 'https://app.cogeunnumero.com/',
        'mantenimiento' => false, // Cambiar a false para deshabilitar 
        'entorno' => 'desarrollo', // 'desarrollo' o 'produccion'
    ],
    'archivos' => [
    ]
];
