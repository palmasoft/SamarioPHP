<?php

class RolPermiso extends Modelo {
}
