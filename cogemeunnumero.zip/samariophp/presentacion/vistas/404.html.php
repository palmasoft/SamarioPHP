<!DOCTYPE html>
<html>
<head>
    <title>Página no encontrada</title>
</head>
<body>
    <h1>Error 404: Página no encontrada</h1>
    <p>La página que buscas no existe.</p>
</body>
</html>
