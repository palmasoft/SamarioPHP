<?php

class UsuarioRol extends Modelo {
}
