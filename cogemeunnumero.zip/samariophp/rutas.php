<?php
use Slim\Routing\RouteCollectorProxy;
// Gestion de Peticiones y Respuestas HTTP//
use Psr\Http\Message\ResponseInterface as Respuesta;
use Psr\Http\Message\ServerRequestInterface as Peticion;
// Configuración de las rutas
return function ($aplicacion, $configuracion, $baseDeDatos, $plantillas, $logger) {
  $logger->info('[RUTAS] Registrando las rutas principales...');

  // Ruta para la página de inicio
  $aplicacion->get(RUTA_INICIO, function (Peticion $peticion, Respuesta $respuesta) use ($baseDeDatos, $plantillas, $logger) {
    $logger->info('[INICIO] Verificando tablas en la base de datos...');

    try {
      $tablas = $GLOBALS['db']->query("SHOW TABLES LIKE 'usuarios' ")->fetchAll();

      if (count($tablas) > 0) {
        $mensaje = 'Todo está funcionando correctamente';
        $contenido = $plantillas->render(VISTA_INICIO, ['mensaje' => $mensaje]);
        $respuesta->getBody()->write($contenido);
        return $respuesta;
      } else {
        $logger->warning('[INICIO] No se encontraron tablas. Redirigiendo a instalación.');
        return $respuesta->withRedirect(RUTA_INSTALAR);
      }
    } catch (Exception $e) {
      $logger->error('[INICIO] Error al verificar las tablas: ' . $e->getMessage());
      throw $e;
    }
  });

  // Ruta para la instalación
  $aplicacion->group(
      RUTA_INSTALAR, function (RouteCollectorProxy $grupo) use ($configuracion, $baseDeDatos, $logger, $plantillas) {

        $grupo->get(
            '', function (Peticion $peticion, Respuesta $respuesta) use ($configuracion, $baseDeDatos, $logger, $plantillas) {
              $logger->info('[INSTALACIÓN] Verificando tablas existentes antes de instalar...');

              try {
                $tablas = $GLOBALS['db']->query(
                        "SELECT * FROM information_schema.tables "
                        . "WHERE table_schema = '{$configuracion['base_de_datos']['nombre_basedatos']}' "
                        . "AND table_name NOT LIKE 'phinx%'; "
                    )->fetchAll();

                if (count($tablas) > 0) {
                  $mensaje = 'La base de datos ya contiene tablas. Elimine las tablas existentes si desea realizar una nueva instalación.';
                  $mensaje_tipo = 'error';
                  $logger->warning('[INSTALACIÓN] Tablas existentes detectadas.');
                } else {
                  $mensaje = 'Bienvenido al instalador de SamarioPHP. Presione \"Iniciar instalación\" para continuar.';
                  $mensaje_tipo = 'iniciar_instalacion';
                }

                $contenido = $plantillas->render(VISTA_INSTALACION, [
                    'config' => $configuracion,
                    'mensaje' => $mensaje,
                    'mensaje_tipo' => $mensaje_tipo
                ]);

                $respuesta->getBody()->write($contenido);
                return $respuesta;
              } catch (Exception $e) {
                $logger->error('[INSTALACIÓN] Error al verificar las tablas: ' . $e->getMessage());
                throw $e;
              }
            }
        );
//
        $grupo->post(
            '', function (Peticion $peticion, Respuesta $respuesta) use ($configuracion, $baseDeDatos, $logger, $plantillas) {
              $logger->info('[INSTALACIÓN] Iniciando proceso de instalación...');

              try {
                include_once RUTA_INSTALADOR;
                $logger->info('[INSTALACIÓN] Instalación completada con éxito.');

                $contenido = $plantillas->render(VISTA_INSTALACION, [
                    'mensaje' => 'Instalación completada con éxito. Ahora puede empezar a usar SamarioPHP.',
                    'mensaje_tipo' => 'exito'
                ]);
                $respuesta->getBody()->write($contenido);
                return $respuesta;
              } catch (Exception $e) {
                $logger->error('[INSTALACIÓN] Error durante la instalación: ' . $e->getMessage());

                $contenido = $plantillas->render(VISTA_INSTALACION, [
                    'mensaje' => 'Hubo un problema durante la instalación. Revise los registros para más detalles.',
                    'mensaje_tipo' => 'error'
                ]);
                $respuesta->getBody()->write($contenido);
                return $respuesta;
              }
            }
        );
      }
  );

  // 
  // 
  // Rutas para autenticación
//  
//  
//  $aplicacion->group(RUTA_AUTENTICACION, function (RouteCollectorProxy $grupo) use ($plantillas, $logger) {
  // Ruta para la vista de inicio de sesión
  $aplicacion->get('/login', function (Peticion $peticion, Respuesta $respuesta) use ($plantillas, $logger) {
    return $respuesta->withRedirect(RUTA_USUARIO_ENTRAR); // Redirige a /autenticacion/login si es necesario
  });

  $aplicacion->get(RUTA_USUARIO_ENTRAR, function (Peticion $peticion, Respuesta $respuesta) use ($plantillas, $logger) {
    $logger->info('[AUTENTICACION] Mostrando página de login');
    $contenido = $plantillas->render('autenticacion/login.html.php');
    $respuesta->getBody()->write($contenido);
    return $respuesta;
  });

  // Ruta para manejar el inicio de sesión
  $aplicacion->post(RUTA_USUARIO_ENTRAR, function (Peticion $peticion, Respuesta $respuesta) use ($logger) {
    $logger->info('[AUTENTICACION] Procesando inicio de sesión');
    $datos = $peticion->getParsedBody();
    $correo = $datos['correo'] ?? '';
    $contrasena = $datos['contrasena'] ?? '';

    // Lógica para verificar las credenciales
    try {
      $usuario = $baseDeDatos->select('usuarios', ['id', 'correo', 'contrasena'], ['correo' => $correo]);

      if (count($usuario) > 0 && password_verify($contrasena, $usuario[0]['contrasena'])) {
        session_start();
        $_SESSION['usuario_id'] = $usuario[0]['id'];
        $_SESSION['usuario_correo'] = $usuario[0]['correo'];

        // Redirigir al inicio o a una página de perfil
        return $respuesta->withRedirect(RUTA_INICIO);
      } else {
        $logger->warning('[AUTENTICACION] Credenciales inválidas');
        return $respuesta->withRedirect('/login')->withStatus(401);
      }
    } catch (Exception $e) {
      $logger->error('[AUTENTICACION] Error al intentar iniciar sesión: ' . $e->getMessage());
      return $respuesta->withRedirect('/login')->withStatus(500);
    }
  });

  // Ruta para la vista de registro
  $aplicacion->get(RUTA_USUARIO_REGISTRO, function (Peticion $peticion, Respuesta $respuesta) use ($plantillas, $logger) {
    $logger->info('[AUTENTICACION] Mostrando página de registro');
    $contenido = $plantillas->render('autenticacion/registro.html.php');
    $respuesta->getBody()->write($contenido);
    return $respuesta;
  });

  // Ruta para manejar el registro de usuario
  $aplicacion->post(RUTA_USUARIO_REGISTRO, function (Peticion $peticion, Respuesta $respuesta) use ($logger) {
    $logger->info('[AUTENTICACION] Procesando registro');

    // Aquí puedes manejar la lógica de registro (validar los datos y crear un nuevo usuario)
    $datos = $peticion->getParsedBody();
    $correo = $datos['correo'] ?? '';
    $contrasena = $datos['contrasena'] ?? '';

    // Crear el nuevo usuario en la base de datos

    return $respuesta->withRedirect(RUTA_INICIO); // O redirigir a una página de éxito
  });

  // Ruta para cerrar sesión
  $aplicacion->get('/logout', function (Peticion $peticion, Respuesta $respuesta) use ($plantillas, $logger) {
    return $respuesta->withRedirect(RUTA_USUARIO_SALIR); // Redirige a /autenticacion/login si es necesario
  });

  $aplicacion->get(RUTA_USUARIO_SALIR, function (Peticion $peticion, Respuesta $respuesta) use ($logger) {
    $logger->info('[AUTENTICACION] Cerrando sesión');

    // Lógica para cerrar la sesión (eliminar datos de sesión)
    session_start();
    session_unset();
    session_destroy();

    return $respuesta->withRedirect(RUTA_INICIO); // Redirige a la página de inicio o login
  });

  // Ruta para mostrar el formulario de recuperación de contraseña
  $aplicacion->get(RUTA_USUARIO_RECUPERAR_CLAVE, function (Peticion $peticion, Respuesta $respuesta) use ($baseDeDatos, $plantillas, $logger) {
    $logger->info('[AUTENTICACION] Mostrando formulario para recuperar contraseña');
    $contenido = $plantillas->render('autenticacion/recuperar_contrasena.html.php');
    $respuesta->getBody()->write($contenido);
    return $respuesta;
  });

// Ruta para verificar el correo electrónico
  $aplicacion->get(RUTA_USUARIO_VERFICACION, function (Peticion $peticion, Respuesta $respuesta, array $args) use ($baseDeDatos, $logger) {
    $token = $args['token'];

    // Verificar token en la base de datos y activar usuario
    try {
      $usuario = $baseDeDatos->select('usuarios', ['id', 'verificado'], ['token_verificacion' => $token]);

      if (count($usuario) > 0 && !$usuario[0]['verificado']) {
        // Activar cuenta
        $baseDeDatos->update('usuarios', ['verificado' => 1], ['id' => $usuario[0]['id']]);
        $contenido = $plantillas->render('autenticacion/verificar_correo.html.php');
      } else {
        $contenido = $plantillas->render('autenticacion/error_verificacion.html.php');
      }

      $respuesta->getBody()->write($contenido);
      return $respuesta;
    } catch (Exception $e) {
      $logger->error('[AUTENTICACION] Error al verificar correo: ' . $e->getMessage());
      return $respuesta->withStatus(500);
    }
  });

//  });
  // 
  // 
  // 
  // 
  // 
  // 
  // 
  // 
  // 
  // 
  // 
  // 
  // 
  // 
  // 
  // 
  // 
  // 
  // Rutas para Adminstracion de Usuarios
  $aplicacion->group(RUTA_USUARIOS, function (RouteCollectorProxy $grupo) {
    $grupo->get('', function (Peticion $peticion, Respuesta $respuesta) {
      // Lógica para listar usuarios
      $respuesta->getBody()->write('Lista de usuarios');
      return $respuesta;
    });

    $grupo->post('/crear', function (Peticion $peticion, Respuesta $respuesta) {
      // Lógica para crear un usuario
      $respuesta->getBody()->write('Crear un usuario');
      return $respuesta;
    });
  });

  // 
  // 
  // 
  // 
  // 
  // Otras rutas
  $aplicacion->get(RUTA_HELLO, function (Peticion $peticion, Respuesta $respuesta, array $args) {
    $name = $args['name'];
    $respuesta->getBody()->write("Hello, $name");
    return $respuesta;
  });

  $aplicacion->get(RUTA_TEST, function (Peticion $peticion, Respuesta $respuesta) {
    $respuesta->getBody()->write('Pruebas del sistema');
    return $respuesta;
  });

  $logger->info('Terminamos de registrar todas las rutas.');
};
