<?php
$configuracion = require_once __DIR__ . '/samariophp/configuracion.php';
$phinx = include __DIR__ . '/samariophp/configuraciones/phinx.php';
return $phinx;
